/* popup.js — Modal popup controller */
"use strict";

const CtaPopup = (() => {
  let currentSolution = null;

  const overlay    = document.getElementById('cta-overlay');
  const modal      = document.getElementById('cta-modal');
  const closeBtn   = document.getElementById('cta-modal-close');
  const tabs       = document.querySelectorAll('.cta-tab');
  const panels     = document.querySelectorAll('.cta-tab-panel');
  const copyBtn    = document.getElementById('cta-modal-copy');
  const newBtn     = document.getElementById('cta-modal-new');
  const eqDisplay  = document.getElementById('cta-modal-eq-display');
  const resultEl   = document.getElementById('cta-modal-result');
  const stepsEl    = document.getElementById('cta-modal-steps');
  const explainEl  = document.getElementById('cta-modal-explain');

  // ---- Open ----
  function open(solution) {
    currentSolution = solution;
    renderContent(solution);
    overlay.style.display = 'flex';
    // activate first tab
    activateTab('cta-tab-result');
    // trap focus
    setTimeout(() => closeBtn.focus(), 100);
    document.body.style.overflow = 'hidden';
  }

  // ---- Close ----
  function close() {
    overlay.style.display = 'none';
    document.body.style.overflow = '';
    currentSolution = null;
  }

  // ---- Render ----
  function renderContent(sol) {
    // Header equation display
    eqDisplay.textContent = sol.equation;

    // --- Tab: Result ---
    resultEl.innerHTML = `
      <div class="cta-modal-answer-label">Solución encontrada</div>
      <div class="cta-modal-answer-val">${escapeHtml(sol.result)}</div>
      <div class="cta-modal-type-badge">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
          <path d="M2 6l3 3 5-5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        ${typeLabel(sol.type)}
      </div>
    `;

    // --- Tab: Steps ---
    stepsEl.innerHTML = '';
    sol.steps.forEach((step, i) => {
      const isLast = i === sol.steps.length - 1;
      const item = document.createElement('div');
      item.innerHTML = `
        <div class="cta-step-item">
          <div>
            <div class="cta-step-num">${i + 1}</div>
            ${!isLast ? '<div class="cta-step-divider" style="margin-top:8px;margin-bottom:-4px;height:18px;"></div>' : ''}
          </div>
          <div class="cta-step-body">
            <div class="cta-step-title">${escapeHtml(step.title)}</div>
            <div class="cta-step-eq">${escapeHtml(step.equation)}</div>
            ${step.note ? `<div class="cta-step-note">${escapeHtml(step.note)}</div>` : ''}
          </div>
        </div>
      `;
      item.style.animationDelay = `${i * 0.06}s`;
      stepsEl.appendChild(item);
    });

    // --- Tab: Explanation ---
    explainEl.innerHTML = '';
    if (Array.isArray(sol.explanation) && sol.explanation.length > 0) {
      sol.explanation.forEach((block, i) => {
        const el = document.createElement('div');
        el.className = 'cta-explain-block';
        el.style.animationDelay = `${i * 0.08}s`;
        el.innerHTML = `
          <div class="cta-explain-block-title ${block.color}">${escapeHtml(block.title)}</div>
          <p class="cta-explain-text">${escapeHtml(block.text)}</p>
        `;
        explainEl.appendChild(el);
      });
    } else {
      explainEl.innerHTML = `<p class="cta-explain-text" style="text-align:center;padding:20px 0;">No hay explicación disponible para esta ecuación.</p>`;
    }
  }

  function typeLabel(type) {
    return {
      linear:     'Ecuación Lineal',
      quadratic:  'Ecuación Cuadrática',
      expression: 'Expresión Matemática'
    }[type] || 'Ecuación Algebraica';
  }

  // ---- Tab switching ----
  function activateTab(tabId) {
    tabs.forEach(t => {
      const active = t.id === tabId;
      t.classList.toggle('cta-tab-active', active);
      t.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    panels.forEach(p => {
      const panelId = tabId.replace('cta-tab-', 'cta-panel-');
      const show = p.id === panelId;
      p.style.display = show ? 'block' : 'none';
    });
  }

  // ---- Copy solution ----
  function copySolution() {
    if (!currentSolution) return;
    const text = `Ecuación: ${currentSolution.equation}\nSolución: ${currentSolution.result}`;
    navigator.clipboard.writeText(text).then(() => {
      CtaApp.showToast('¡Copiado al portapapeles!', 'success');
    }).catch(() => {
      CtaApp.showToast('No se pudo copiar.', 'error');
    });
  }

  // ---- Escape HTML ----
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ---- Event Listeners ----
  closeBtn.addEventListener('click', close);

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay.style.display !== 'none') close();
  });

  tabs.forEach(tab => {
    tab.addEventListener('click', () => activateTab(tab.id));
  });

  copyBtn.addEventListener('click', copySolution);

  newBtn.addEventListener('click', () => {
    close();
    document.getElementById('cta-equation').focus();
  });

  return { open, close };
})();
