/* animations.js — Background and UI animations */
"use strict";

const CtaAnimations = (() => {

  // Stagger animate children of an element into view
  function staggerIn(parentEl, childSelector, baseDelay = 0, stepDelay = 60) {
    if (!parentEl) return;
    const children = parentEl.querySelectorAll(childSelector);
    children.forEach((child, i) => {
      child.style.opacity = '0';
      child.style.transform = 'translateY(12px)';
      child.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
      setTimeout(() => {
        child.style.opacity = '1';
        child.style.transform = 'translateY(0)';
      }, baseDelay + i * stepDelay);
    });
  }

  // Shake animation for input errors
  function shake(el) {
    if (!el) return;
    el.style.animation = 'none';
    el.offsetHeight; // reflow
    el.style.animation = 'cta-shake 0.4s ease';
    setTimeout(() => { el.style.animation = ''; }, 400);
  }

  // Pulse glow effect for result card
  function pulseGlow(el, color = 'rgba(6,182,212,0.4)') {
    if (!el) return;
    el.style.transition = 'box-shadow 0.3s ease';
    el.style.boxShadow = `0 0 40px ${color}`;
    setTimeout(() => {
      el.style.boxShadow = '';
    }, 600);
  }

  // Button press ripple
  function addRipple(btn) {
    if (!btn) return;
    btn.addEventListener('click', function(e) {
      const ripple = document.createElement('span');
      const rect = btn.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height) * 1.5;
      ripple.style.cssText = `
        position:absolute;
        border-radius:50%;
        background:rgba(255,255,255,0.15);
        width:${size}px;
        height:${size}px;
        top:${e.clientY - rect.top - size/2}px;
        left:${e.clientX - rect.left - size/2}px;
        animation:cta-ripple 0.5s ease-out forwards;
        pointer-events:none;
      `;
      btn.style.position = 'relative';
      btn.style.overflow = 'hidden';
      btn.appendChild(ripple);
      setTimeout(() => ripple.remove(), 500);
    });
  }

  // Add shake keyframes + ripple keyframes dynamically
  function injectKeyframes() {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes cta-shake {
        0%,100% { transform: translateX(0); }
        15%  { transform: translateX(-6px); }
        30%  { transform: translateX(6px); }
        45%  { transform: translateX(-4px); }
        60%  { transform: translateX(4px); }
        75%  { transform: translateX(-2px); }
        90%  { transform: translateX(2px); }
      }
      @keyframes cta-ripple {
        from { opacity: 0.6; transform: scale(0); }
        to   { opacity: 0;   transform: scale(1); }
      }
    `;
    document.head.appendChild(style);
  }

  // Init: apply ripple to solve button + keyboard buttons
  function init() {
    injectKeyframes();

    const solveBtn = document.getElementById('cta-solve-btn');
    if (solveBtn) addRipple(solveBtn);

    const kbBtns = document.querySelectorAll('.cta-kb-btn');
    kbBtns.forEach(b => addRipple(b));

    // Scroll-animate the floating symbols with slight parallax
    let ticking = false;
    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          const syms = document.querySelectorAll('.cta-sym');
          const scrollY = window.scrollY || window.pageYOffset;
          syms.forEach((s, i) => {
            const dir = i % 2 === 0 ? 1 : -1;
            s.style.transform = `translateY(${scrollY * 0.03 * dir}px)`;
          });
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });
  }

  return { init, shake, pulseGlow, staggerIn };
})();
