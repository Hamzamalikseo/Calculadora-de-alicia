/* solver.js — Algebra solving engine with Spanish step explanations */
"use strict";

const AlgebraSolver = (() => {

  /**
   * Parse & classify the equation type
   */
  function classifyEquation(eq) {
    const str = eq.replace(/\s+/g, '');
    const hasEquals = str.includes('=');
    const lhs = hasEquals ? str.split('=')[0] : str;

    const degree = detectDegree(lhs);
    if (!hasEquals) return 'expression';
    if (degree >= 2)  return 'quadratic';
    return 'linear';
  }

  function detectDegree(expr) {
    if (/\^3|\*\*3/.test(expr)) return 3;
    if (/\^2|\*\*2|x\*x/.test(expr)) return 2;
    return 1;
  }

  /**
   * Solve an equation string.
   * Returns { result, steps, explanation, type, equation }
   */
  function solve(rawInput) {
    const input = rawInput.trim();

    if (!input) throw new Error('EMPTY');

    if (!input.includes('=')) {
      // Just evaluate as expression
      return solveExpression(input);
    }

    const parts = input.split('=');
    if (parts.length !== 2) throw new Error('INVALID');

    const lhs = parts[0].trim();
    const rhs = parts[1].trim();

    const type = classifyEquation(input);

    if (type === 'quadratic') return solveQuadratic(lhs, rhs, input);
    return solveLinear(lhs, rhs, input);
  }

  /* ---- Evaluate pure expression ---- */
  function solveExpression(expr) {
    try {
      const val = math.evaluate(expr);
      const display = formatVal(val);
      return {
        type: 'expression',
        equation: expr,
        result: display,
        steps: [
          {
            title: 'Evaluar la expresión',
            equation: expr,
            note: 'Calculamos el valor de la expresión directamente.'
          },
          {
            title: 'Resultado',
            equation: `= ${display}`,
            note: 'Este es el valor numérico de la expresión.'
          }
        ],
        explanation: buildExpressionExplanation(expr, display)
      };
    } catch(e) {
      throw new Error('INVALID');
    }
  }

  /* ---- Linear equation solver ---- */
  function solveLinear(lhs, rhs, original) {
    const steps = [];
    const explanation = [];

    steps.push({
      title: 'Ecuación original',
      equation: `${lhs} = ${rhs}`,
      note: 'Esta es la ecuación que vamos a resolver.'
    });

    // Build equation: move everything to lhs - rhs = 0
    const combined = `(${lhs}) - (${rhs})`;
    let expr;
    try {
      expr = math.parse(combined).toString();
    } catch(e) { throw new Error('INVALID'); }

    // Find the variable
    const vars = findVariables(lhs + rhs);
    if (vars.length === 0) {
      // No variable → just check equality
      try {
        const diff = math.evaluate(combined);
        const isTrue = Math.abs(diff) < 1e-10;
        return {
          type: 'linear',
          equation: original,
          result: isTrue ? 'Verdadero (∞ soluciones)' : 'Falso (sin solución)',
          steps: [
            { title: 'Ecuación original', equation: `${lhs} = ${rhs}`, note: '' },
            {
              title: isTrue ? 'Identidad' : 'Contradicción',
              equation: isTrue ? '∞ soluciones' : 'Sin solución',
              note: isTrue
                ? 'Ambos lados son iguales para cualquier valor.'
                : 'Los lados no son iguales.'
            }
          ],
          explanation: []
        };
      } catch(e) { throw new Error('INVALID'); }
    }

    const varName = vars[0];

    // Try math.js to solve symbolically
    let solution;
    try {
      solution = math.evaluate(`solve(${combined}, ${varName})`);
    } catch(e) {
      // fallback: numerical
      solution = numericalSolve(combined, varName);
    }

    const solVal = Array.isArray(solution)
      ? (solution.length > 0 ? solution[0] : null)
      : solution;

    if (solVal === null || solVal === undefined) throw new Error('NO_SOLUTION');

    const solDisplay = formatVal(solVal);

    // Build Spanish steps
    steps.push(...buildLinearSteps(lhs, rhs, varName, solVal, solDisplay));

    return {
      type: 'linear',
      equation: original,
      result: `${varName} = ${solDisplay}`,
      steps,
      explanation: buildLinearExplanation(lhs, rhs, varName, solDisplay, original)
    };
  }

  /* ---- Build linear steps ---- */
  function buildLinearSteps(lhs, rhs, varName, solVal, solDisplay) {
    const steps = [];

    // Step: identify goal
    steps.push({
      title: `Identificar la variable: ${varName}`,
      equation: `${lhs} = ${rhs}`,
      note: `Necesitamos aislar la variable ${varName} en un lado de la ecuación.`
    });

    // Check if there are constants on the lhs side
    // Try to detect pattern like ax + b = c  or ax = b
    const lhsClean = lhs.replace(/\s/g, '');
    const rhsClean = rhs.replace(/\s/g, '');

    // Try to extract coefficient and constant
    let a = null, b = null, c = null;
    try {
      // Evaluate as function of varName
      const scope1 = {}; scope1[varName] = 0;
      const scope2 = {}; scope2[varName] = 1;

      const f0 = math.evaluate(lhsClean, scope1) - math.evaluate(rhsClean, scope1);
      const f1 = math.evaluate(lhsClean, scope2) - math.evaluate(rhsClean, scope2);

      // f(x) = slope * x + intercept
      const slope = f1 - f0;
      const intercept = f0;

      a = slope;
      b = -intercept; // we want ax = b

      if (Math.abs(slope) < 1e-10) {
        // No variable terms — weird
        return steps;
      }

      // Transpose constants
      if (Math.abs(intercept) > 1e-10) {
        const transposed = formatVal(-intercept);
        const sign = intercept < 0 ? `+ ${formatVal(-intercept)}` : `- ${formatVal(-intercept)}`;
        steps.push({
          title: 'Mover los términos constantes',
          equation: `${formatVal(slope)}${varName} = ${formatVal(-intercept)}`,
          note: `Trasladamos el término constante al otro lado ${intercept < 0 ? 'sumando' : 'restando'} ${formatVal(Math.abs(intercept))} en ambos lados.`
        });
      }

      if (Math.abs(slope) !== 1) {
        steps.push({
          title: `Dividir entre el coeficiente ${formatVal(slope)}`,
          equation: `${varName} = ${formatVal(-intercept)} ÷ ${formatVal(slope)}`,
          note: `Dividimos ambos lados entre ${formatVal(slope)} para despejar ${varName}.`
        });
      }

    } catch(e) { /* ignore */ }

    // Final result step
    steps.push({
      title: 'Solución',
      equation: `${varName} = ${solDisplay}`,
      note: `✓ Hemos despejado ${varName} con éxito.`
    });

    // Verification step
    steps.push({
      title: 'Verificación',
      equation: `${lhs.replace(new RegExp(varName, 'g'), `(${solDisplay})`)} = ${rhs}`,
      note: 'Sustituimos el valor encontrado para verificar que la ecuación es correcta.'
    });

    return steps;
  }

  /* ---- Quadratic solver ---- */
  function solveQuadratic(lhs, rhs, original) {
    const steps = [];

    steps.push({
      title: 'Ecuación original',
      equation: original,
      note: 'Identificamos que es una ecuación cuadrática (grado 2).'
    });

    const vars = findVariables(lhs + rhs);
    const varName = vars.length > 0 ? vars[0] : 'x';

    // Move everything to one side: lhs - rhs = 0
    const combined = `(${lhs}) - (${rhs})`;

    // Extract a, b, c from ax² + bx + c = 0
    let a, b, c;
    try {
      const scope0 = {}; scope0[varName] = 0;
      const scope1 = {}; scope1[varName] = 1;
      const scope2 = {}; scope2[varName] = 2;
      const scopeN1 = {}; scopeN1[varName] = -1;

      const f0  = math.evaluate(combined, scope0);
      const f1  = math.evaluate(combined, scope1);
      const fN1 = math.evaluate(combined, scopeN1);

      // f(x) = ax² + bx + c
      c = f0;
      b = (f1 - fN1) / 2;
      a = f1 - b - c;

      if (Math.abs(a) < 1e-10) {
        // Not actually quadratic — fall back to linear
        return solveLinear(lhs, rhs, original);
      }

    } catch(e) {
      throw new Error('INVALID');
    }

    const aStr = formatVal(a);
    const bStr = formatVal(b);
    const cStr = formatVal(c);

    // Standard form step
    steps.push({
      title: 'Forma estándar: ax² + bx + c = 0',
      equation: `${aStr}${varName}² ${b >= 0 ? '+' : ''} ${bStr}${varName} ${c >= 0 ? '+' : ''} ${cStr} = 0`,
      note: `Coeficientes: a = ${aStr}, b = ${bStr}, c = ${cStr}`
    });

    // Discriminant
    const disc = b * b - 4 * a * c;
    const discStr = formatVal(disc);

    steps.push({
      title: 'Calcular el discriminante: Δ = b² − 4ac',
      equation: `Δ = (${bStr})² − 4·(${aStr})·(${cStr}) = ${discStr}`,
      note: disc > 0
        ? 'Δ > 0: La ecuación tiene dos soluciones reales distintas.'
        : disc === 0
        ? 'Δ = 0: La ecuación tiene una solución real (raíz doble).'
        : 'Δ < 0: La ecuación no tiene soluciones reales.'
    });

    let result, roots;

    if (disc < 0) {
      // Complex roots
      const realPart = -b / (2 * a);
      const imagPart = Math.sqrt(-disc) / (2 * a);
      result = `${varName}₁ = ${formatVal(realPart)} + ${formatVal(imagPart)}i, ${varName}₂ = ${formatVal(realPart)} − ${formatVal(imagPart)}i`;
      steps.push({
        title: 'Soluciones complejas',
        equation: result,
        note: 'Las soluciones son números complejos (imaginarios).'
      });
    } else {
      const x1 = (-b + Math.sqrt(disc)) / (2 * a);
      const x2 = (-b - Math.sqrt(disc)) / (2 * a);

      steps.push({
        title: `Aplicar la fórmula cuadrática: ${varName} = (−b ± √Δ) / 2a`,
        equation: `${varName} = (−(${bStr}) ± √${discStr}) / (2·${aStr})`,
        note: 'Sustituimos los valores en la fórmula general.'
      });

      if (Math.abs(x1 - x2) < 1e-10) {
        result = `${varName} = ${formatVal(x1)}`;
        steps.push({
          title: 'Solución única (raíz doble)',
          equation: result,
          note: `El discriminante es 0, por lo que ${varName} tiene un único valor.`
        });
      } else {
        result = `${varName}₁ = ${formatVal(x1)},  ${varName}₂ = ${formatVal(x2)}`;
        steps.push({
          title: 'Dos soluciones reales',
          equation: `${varName}₁ = ${formatVal(x1)}   |   ${varName}₂ = ${formatVal(x2)}`,
          note: 'La ecuación tiene dos raíces reales distintas.'
        });
      }
    }

    return {
      type: 'quadratic',
      equation: original,
      result,
      steps,
      explanation: buildQuadraticExplanation(a, b, c, disc, varName, result)
    };
  }

  /* ---- Build explanations ---- */
  function buildLinearExplanation(lhs, rhs, varName, solDisplay, original) {
    return [
      {
        title: '¿Qué tipo de ecuación es?',
        color: 'ct-primary',
        text: `Esta es una ecuación lineal (de primer grado) con la variable ${varName}. Las ecuaciones lineales forman una línea recta al graficarlas.`
      },
      {
        title: 'Estrategia de resolución',
        color: 'ct-accent',
        text: `Para resolver ecuaciones lineales, aplicamos operaciones inversas en ambos lados para aislar ${varName}. Si sumamos o restamos algo de un lado, debemos hacer lo mismo en el otro.`
      },
      {
        title: 'Resultado final',
        color: 'ct-success',
        text: `La solución es ${varName} = ${solDisplay}. Esto significa que cuando sustituimos este valor en la ecuación original, ambos lados son iguales.`
      },
      {
        title: 'Consejo del tutor',
        color: 'ct-gold',
        text: `Siempre verifica tu respuesta sustituyendo el valor en la ecuación original. ¡Es la mejor manera de asegurarte de que tu solución es correcta!`
      }
    ];
  }

  function buildQuadraticExplanation(a, b, c, disc, varName, result) {
    return [
      {
        title: '¿Qué es una ecuación cuadrática?',
        color: 'ct-primary',
        text: `Una ecuación cuadrática tiene la forma ax² + bx + c = 0, donde a ≠ 0. Se llama "cuadrática" porque el exponente más alto es 2. Su gráfica forma una parábola.`
      },
      {
        title: 'El discriminante (Δ)',
        color: 'ct-accent',
        text: `El discriminante Δ = b² − 4ac = ${formatVal(disc)} nos dice cuántas soluciones tiene la ecuación. ${disc > 0 ? 'Como Δ > 0, hay dos soluciones reales distintas.' : disc === 0 ? 'Como Δ = 0, hay exactamente una solución (raíz doble).' : 'Como Δ < 0, no hay soluciones reales.'}`
      },
      {
        title: 'La fórmula cuadrática',
        color: 'ct-success',
        text: `Usamos la fórmula general: x = (−b ± √Δ) / 2a. Con a = ${formatVal(a)}, b = ${formatVal(b)}, c = ${formatVal(c)}. Esta fórmula siempre funciona para cualquier ecuación cuadrática.`
      },
      {
        title: 'Interpretación geométrica',
        color: 'ct-gold',
        text: `Las soluciones representan los puntos donde la parábola f(x) = ${formatVal(a)}x² ${b >= 0 ? '+' : ''} ${formatVal(b)}x ${c >= 0 ? '+' : ''} ${formatVal(c)} corta al eje x.`
      }
    ];
  }

  function buildExpressionExplanation(expr, result) {
    return [
      {
        title: 'Evaluación de expresión',
        color: 'ct-primary',
        text: `Calculamos el valor numérico de la expresión "${expr}". No hay variables, por lo que solo necesitamos aplicar las operaciones matemáticas.`
      },
      {
        title: 'Resultado',
        color: 'ct-success',
        text: `El valor de la expresión es ${result}.`
      }
    ];
  }

  /* ---- Utilities ---- */
  function findVariables(expr) {
    const varRegex = /\b([a-z])\b/g;
    const found = new Set();
    let m;
    const reserved = new Set(['e', 'i', 'pi', 'sin', 'cos', 'tan', 'log', 'ln', 'sqrt', 'abs']);
    while ((m = varRegex.exec(expr)) !== null) {
      if (!reserved.has(m[1])) found.add(m[1]);
    }
    // prioritize x, then y, then z, then alphabetically
    const priority = ['x','y','z','a','b','c','n','m'];
    for (const p of priority) {
      if (found.has(p)) return [p, ...Array.from(found).filter(v => v !== p)];
    }
    return Array.from(found);
  }

  function formatVal(val) {
    if (typeof val === 'number') {
      if (!isFinite(val)) return '∞';
      if (Math.abs(val - Math.round(val)) < 1e-10) return String(Math.round(val));
      // Try to express as simple fraction
      const frac = toFraction(val);
      if (frac) return frac;
      return parseFloat(val.toFixed(6)).toString();
    }
    if (typeof val === 'object' && val !== null && val.re !== undefined) {
      // complex
      return `${formatVal(val.re)} + ${formatVal(val.im)}i`;
    }
    return String(val);
  }

  function toFraction(x, tolerance = 1e-8, maxDenom = 1000) {
    if (Math.abs(x) > 1e6) return null;
    let num = 1, den = 1;
    let h1=1, h2=0, k1=0, k2=1;
    let b = x;
    do {
      const a = Math.floor(b);
      let aux = h1;
      h1 = a * h1 + h2;
      h2 = aux;
      aux = k1;
      k1 = a * k1 + k2;
      k2 = aux;
      b = 1 / (b - a);
    } while (Math.abs(x - h1/k1) > x * tolerance && k1 <= maxDenom);

    if (k1 > 1 && k1 <= maxDenom && Math.abs(x - h1/k1) < tolerance) {
      return `${h1}/${k1}`;
    }
    return null;
  }

  function numericalSolve(expr, varName, x0 = 0, tol = 1e-10, maxIter = 100) {
    let x = x0;
    for (let i = 0; i < maxIter; i++) {
      const scope = {}; scope[varName] = x;
      const scopeDx = {}; scopeDx[varName] = x + 1e-7;
      try {
        const fx = math.evaluate(expr, scope);
        const fxDx = math.evaluate(expr, scopeDx);
        const deriv = (fxDx - fx) / 1e-7;
        if (Math.abs(deriv) < 1e-15) break;
        const xNew = x - fx / deriv;
        if (Math.abs(xNew - x) < tol) return xNew;
        x = xNew;
      } catch(e) { break; }
    }
    return x;
  }

  return { solve };
})();
