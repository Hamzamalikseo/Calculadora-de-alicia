/* app.js — Main application controller */
"use strict";

const CtaApp = (() => {

  // ---- DOM Refs ----
  const inputEl       = document.getElementById('cta-equation');
  const inputWrapper  = document.getElementById('cta-input-wrapper');
  const clearBtn      = document.getElementById('cta-clear-btn');
  const solveBtn      = document.getElementById('cta-solve-btn');
  const stickySolve   = document.getElementById('cta-sticky-solve-btn');
  const loader        = document.getElementById('cta-loader');
  const resultCard    = document.getElementById('cta-result-card');
  const resultEq      = document.getElementById('cta-result-equation');
  const resultAns     = document.getElementById('cta-result-answer');
  const stepsBtn      = document.getElementById('cta-steps-btn');
  const copyBtn       = document.getElementById('cta-copy-btn');
  const emptyState    = document.getElementById('cta-empty-state');
  const historySection= document.getElementById('cta-history-section');
  const historyList   = document.getElementById('cta-history-list');
  const historyClear  = document.getElementById('cta-history-clear');
  const toastEl       = document.getElementById('cta-toast');
  const exampleBtns   = document.querySelectorAll('.cta-example-btn');
  const kbBtns        = document.querySelectorAll('.cta-kb-btn');
  const backspaceBtn  = document.getElementById('cta-backspace-btn');

  let history = [];
  let lastSolution = null;
  let toastTimer = null;
  let solving = false;

  // ---- Init ----
  function init() {
    CtaAnimations.init();
    bindEvents();
    loadHistory();
    inputEl.focus();
  }

  // ---- Bind Events ----
  function bindEvents() {
    // Keyboard buttons
    kbBtns.forEach(btn => {
      if (btn.id === 'cta-backspace-btn') return;
      btn.addEventListener('click', () => {
        const ins = btn.dataset.insert;
        if (ins) insertAtCursor(ins);
        inputEl.focus();
      });
    });

    backspaceBtn.addEventListener('click', () => {
      const inp = inputEl;
      const start = inp.selectionStart;
      const end   = inp.selectionEnd;
      if (start !== end) {
        setVal(inp.value.slice(0, start) + inp.value.slice(end));
        setCaretPos(inp, start);
      } else if (start > 0) {
        setVal(inp.value.slice(0, start - 1) + inp.value.slice(start));
        setCaretPos(inp, start - 1);
      }
      inp.focus();
    });

    // Example buttons
    exampleBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        inputEl.value = btn.dataset.eq;
        inputEl.focus();
        triggerSolve();
      });
    });

    // Clear
    clearBtn.addEventListener('click', () => {
      inputEl.value = '';
      inputEl.focus();
    });

    // Solve
    solveBtn.addEventListener('click', triggerSolve);
    if (stickySolve) stickySolve.addEventListener('click', triggerSolve);

    // Enter key
    inputEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') triggerSolve();
    });

    // Steps button
    stepsBtn.addEventListener('click', () => {
      if (lastSolution) CtaPopup.open(lastSolution);
    });

    // Copy result
    copyBtn.addEventListener('click', copyResult);

    // History clear
    historyClear.addEventListener('click', clearHistory);
  }

  // ---- Main Solve Flow ----
  function triggerSolve() {
    if (solving) return;
    const eq = inputEl.value.trim();
    if (!eq) {
      showToast('Escribe una ecuación primero.', 'error');
      CtaAnimations.shake(inputWrapper);
      inputEl.focus();
      return;
    }

    setSolving(true);

    // Simulate a brief async for smooth UX
    setTimeout(() => {
      try {
        const solution = AlgebraSolver.solve(preprocessInput(eq));
        lastSolution = solution;
        showResult(solution);
        addToHistory(solution);
        // Auto-open popup
        setTimeout(() => CtaPopup.open(solution), 350);
      } catch(e) {
        handleError(e);
      } finally {
        setSolving(false);
      }
    }, 600);
  }

  // ---- Show Result ----
  function showResult(sol) {
    resultEq.textContent = sol.equation;
    resultAns.textContent = sol.result;
    emptyState.style.display = 'none';
    resultCard.style.display = 'block';
    CtaAnimations.pulseGlow(resultCard);
  }

  // ---- Loading state ----
  function setSolving(on) {
    solving = on;
    solveBtn.classList.toggle('cta-loading', on);
    loader.classList.toggle('cta-show', on);
    solveBtn.disabled = on;
    if (stickySolve) stickySolve.disabled = on;
  }

  // ---- Error handling ----
  function handleError(e) {
    const msg = e.message;
    let toast;
    if (msg === 'EMPTY') {
      toast = 'Por favor escribe una ecuación.';
    } else if (msg === 'NO_SOLUTION') {
      toast = 'Esta ecuación no tiene solución real.';
    } else {
      toast = 'La ecuación no es válida. Revisa la sintaxis.';
    }
    showToast(toast, 'error');
    CtaAnimations.shake(inputWrapper);
  }

  // ---- Input pre-processing ----
  function preprocessInput(str) {
    return str
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/\^2/g, '^2')
      .replace(/\^3/g, '^3')
      .replace(/π/g, 'pi')
      .replace(/(\d)\s*([a-zA-Z])/g, '$1*$2')   // 2x → 2*x
      .replace(/([a-zA-Z])\s*\(/g, '$1*(')        // x( → x*(  (only for vars)
      .replace(/\)\s*\(/g, ')*(')                  // )( → )*(
      .replace(/\)\s*([0-9a-zA-Z])/g, ')*$1')     // )x → )*x
      .trim();
  }

  // ---- History ----
  function addToHistory(sol) {
    history.unshift({ equation: sol.equation, result: sol.result, solution: sol });
    if (history.length > 10) history.pop();
    saveHistory();
    renderHistory();
  }

  function renderHistory() {
    if (history.length === 0) {
      historySection.style.display = 'none';
      return;
    }
    historySection.style.display = 'block';
    historyList.innerHTML = '';
    history.forEach((item, i) => {
      const el = document.createElement('div');
      el.className = 'cta-history-item';
      el.setAttribute('role', 'listitem');
      el.setAttribute('tabindex', '0');
      el.setAttribute('aria-label', `${item.equation} = ${item.result}`);
      el.innerHTML = `
        <span class="cta-history-eq">${escapeHtml(item.equation)}</span>
        <span class="cta-history-ans">${escapeHtml(truncate(item.result, 20))}</span>
      `;
      el.addEventListener('click', () => {
        inputEl.value = item.equation;
        lastSolution = item.solution;
        showResult(item.solution);
        CtaPopup.open(item.solution);
      });
      el.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') el.click();
      });
      historyList.appendChild(el);
    });
  }

  function clearHistory() {
    history = [];
    saveHistory();
    renderHistory();
    historySection.style.display = 'none';
  }

  function saveHistory() {
    try {
      const safe = history.map(h => ({ equation: h.equation, result: h.result }));
      localStorage.setItem('cta_history', JSON.stringify(safe));
    } catch(e) { /* ignore in iframe contexts */ }
  }

  function loadHistory() {
    try {
      const raw = localStorage.getItem('cta_history');
      if (raw) {
        const parsed = JSON.parse(raw);
        // Lightweight restore (no full solution object)
        history = parsed.map(h => ({ ...h, solution: null }));
        renderHistory();
      }
    } catch(e) { history = []; }
  }

  // ---- Copy Result ----
  function copyResult() {
    if (!lastSolution) return;
    const text = `${lastSolution.equation} → ${lastSolution.result}`;
    navigator.clipboard.writeText(text).then(() => {
      showToast('¡Resultado copiado!', 'success');
    }).catch(() => {
      showToast('No se pudo copiar.', 'error');
    });
  }

  // ---- Toast ----
  function showToast(message, type = 'info') {
    clearTimeout(toastTimer);
    toastEl.textContent = message;
    toastEl.className = `cta-toast cta-toast-${type} cta-toast-show`;
    toastTimer = setTimeout(() => {
      toastEl.classList.remove('cta-toast-show');
    }, 3000);
  }

  // ---- Cursor helpers ----
  function insertAtCursor(text) {
    const inp = inputEl;
    const start = inp.selectionStart;
    const end   = inp.selectionEnd;
    const newVal = inp.value.slice(0, start) + text + inp.value.slice(end);
    setVal(newVal);
    const newPos = start + text.length;
    setCaretPos(inp, newPos);
  }

  function setVal(val) {
    inputEl.value = val;
  }

  function setCaretPos(inp, pos) {
    requestAnimationFrame(() => {
      inp.setSelectionRange(pos, pos);
    });
  }

  // ---- Utils ----
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function truncate(str, len) {
    return str.length > len ? str.slice(0, len) + '…' : str;
  }

  // ---- Expose public ----
  return { init, showToast };
})();

// Boot
document.addEventListener('DOMContentLoaded', () => CtaApp.init());
